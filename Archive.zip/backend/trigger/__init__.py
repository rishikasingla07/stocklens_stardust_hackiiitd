"""Move detection."""
